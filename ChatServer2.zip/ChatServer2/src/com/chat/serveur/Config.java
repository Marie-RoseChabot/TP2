package com.chat.serveur;

/**
 * Informations sur un serveur, utilis�es par d�faut.
 */
public interface Config {
    /**
     * Port d'�coute du serveur.
     */
    int PORT_SERVEUR = 8888;
}
